"use client";

import { usePathname } from "next/navigation";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export default function ClientLayoutWrapper({ children }) {
  const pathname = usePathname();
  const isAdmin = pathname?.startsWith("/admin");

  return (
    <>
      {!isAdmin && <Navbar />}
      <main className={!isAdmin ? "flex-1 relative z-10 pt-20" : "flex-1 relative z-10"}>
        {children}
      </main>
      {!isAdmin && <Footer />}
    </>
  );
}
