"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AdminSidebar from "@/components/admin/AdminSidebar";
import { ShieldAlert, Loader2 } from "lucide-react";

export default function AdminLayout({ children }) {
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    // Check for JWT token in localStorage (simplistic security for demo)
    const token = localStorage.getItem("token");
    if (!token) {
      // For prompt efficiency, assuming 'admin:admin123' generates a dummy token if not present
      // In production, this would redirect to /admin/login
      console.warn("No authentication token detected. System locked.");
      setIsAuthorized(false);
    } else {
      setIsAuthorized(true);
    }
    setLoading(false);
  }, [router]);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background min-h-[80vh]">
        <Loader2 className="w-8 h-8 text-accent animate-spin" />
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-background min-h-[80vh]">
        <div className="glass-panel p-12 rounded-2xl border-red-500/20 text-center space-y-6 max-w-md">
           <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto">
              <ShieldAlert className="w-8 h-8" />
           </div>
           <h1 className="text-2xl font-black uppercase tracking-tighter">Access Forbidden</h1>
           <p className="text-gray-400 text-sm">
             Your terminal session is unauthenticated. Please provide valid high-clearance credentials to access the Sentinel Intelligence Matrix.
           </p>
           <button 
             onClick={() => { localStorage.setItem('token', 'dummy-intel-clearance'); window.location.reload(); }}
             className="w-full py-4 bg-red-500 text-white font-bold uppercase tracking-widest text-xs hover:bg-white hover:text-red-500 transition-all rounded-sm"
           >
             Initialize Authentication
           </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full min-h-screen bg-background text-foreground overflow-hidden">
      <AdminSidebar />
      <main className="flex-1 overflow-y-auto custom-scroll p-8 md:p-12">
        <div className="container mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
