"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import { useParams } from "next/navigation";
import Markdown from "@/components/ui/Markdown";
import { 
  User, 
  Calendar, 
  Clock, 
  Share2, 
  Loader2,
  ChevronLeft
} from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function ArticlePage() {
  const { slug } = useParams();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (slug) fetchArticle();
  }, [slug]);

  const fetchArticle = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}`}/api/public/articles/${slug}`);
      if (res.ok) {
        setArticle(await res.json());
      }
    } catch (e) {
      console.error("Fetch failed");
    }
    setLoading(false);
  };

  if (loading) return <div className="flex h-screen items-center justify-center bg-background"><Loader2 className="w-12 h-12 animate-spin text-accent" /></div>;
  if (!article) return <div className="flex h-screen items-center justify-center bg-background">Article not found</div>;

  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": ["NewsArticle", "TechArticle", "Article"],
        "headline": article.title,
        "description": article.summary,
        "image": [article.image_url || "https://sentinelreign.com/default.jpg"],
        "datePublished": article.published_at,
        "dateModified": article.updated_at || article.published_at,
        "author": {
          "@type": "Person",
          "name": article.author?.name || article.author_name || "Syed Abrar",
          "url": article.author?.url || "https://sentinelreign.com/author-syed-abrar.html",
          "description": article.author?.bio || "Founder SentinelReign. Kulgam hacker → NDA grind → tech intel.",
          "jobTitle": article.author?.credentials || "Lead Security Researcher",
          "worksFor": {
            "@type": "Organization",
            "name": "SentinelReign"
          }
        },
        "publisher": {
          "@type": "Organization",
          "name": "SentinelReign",
          "logo": {
            "@type": "ImageObject",
            "url": "https://sentinelreign.com/logo.png"
          }
        }
      },
      {
        "@type": "WebPage",
        "@id": `https://sentinelreign.com/article/${slug}`,
        "url": `https://sentinelreign.com/article/${slug}`,
        "name": article.title,
        "description": article.summary,
        "isPartOf": {
          "@type": "WebSite",
          "name": "SentinelReign",
          "url": "https://sentinelreign.com/"
        }
      }
    ]
  };

  return (
    <article className="pb-32 pt-20">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      
      {/* Article Header */}
      <div className="relative h-[60vh] min-h-[500px] w-full mb-16 overflow-hidden rounded-b-[40px] shadow-2xl">
        {article.image_url ? (
          <Image
            src={article.image_url}
            alt={article.title}
            fill
            className="object-cover"
            priority
          />
        ) : (
          <div className="w-full h-full bg-muted flex items-center justify-center">
             <span className="text-xs font-bold uppercase tracking-widest opacity-20">No Image Asset</span>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        
        <div className="absolute bottom-0 left-0 right-0 pb-16">
          <div className="container-wide">
            <div className="max-w-4xl space-y-6">
               <motion.div 
                 initial={{ opacity: 0, x: -20 }}
                 animate={{ opacity: 1, x: 0 }}
                 className="inline-flex items-center gap-2 px-3 py-1 bg-accent text-white text-[10px] font-bold uppercase tracking-widest rounded-full"
               >
                 {article.category || "General"}
               </motion.div>
               <motion.h1 
                 initial={{ opacity: 0, y: 20 }}
                 animate={{ opacity: 1, y: 0 }}
                 transition={{ delay: 0.2 }}
                 className="text-4xl md:text-7xl font-extrabold tracking-tight leading-[1.1]"
               >
                 {article.title}
               </motion.h1>
               <motion.div 
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 transition={{ delay: 0.4 }}
                 className="flex flex-wrap items-center gap-8 text-[11px] font-bold text-gray-400 uppercase tracking-widest"
               >
                 <span className="flex items-center gap-2"><User className="w-4 h-4 text-accent" /> {article.author_name || "Sentinel"}</span>
                 <span className="flex items-center gap-2"><Calendar className="w-4 h-4 text-accent" /> {new Date(article.published_at).toLocaleDateString()}</span>
                 <span className="flex items-center gap-2"><Clock className="w-4 h-4 text-accent" /> 8 min read</span>
               </motion.div>
            </div>
          </div>
        </div>
      </div>

      <div className="container-wide">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Main Content */}
          <div className="lg:col-span-8 space-y-12">
            <div className="pro-card p-8 md:p-12">
               <Markdown content={article.content} />
            </div>

            <div className="pt-12 border-t border-white/5 flex flex-wrap gap-3">
               {["Cybersecurity", "Research", "Analysis", "Deep Tech"].map(tag => (
                 <span key={tag} className="px-4 py-2 bg-muted rounded-lg text-[10px] font-bold uppercase tracking-widest text-gray-400 border border-white/5 hover:border-accent hover:text-accent transition-colors cursor-default">
                   {tag}
                 </span>
               ))}
            </div>
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-4 space-y-10">
             <div className="pro-card p-8 space-y-6 sticky top-32">
                <h3 className="text-lg font-bold uppercase tracking-tight text-white border-b border-white/5 pb-4 flex items-center gap-2">
                   <Share2 className="w-5 h-5 text-accent" /> Share Article
                </h3>
                <div className="grid grid-cols-2 gap-4">
                   <button className="flex items-center justify-center gap-2 p-3 bg-muted rounded-lg border border-white/5 hover:bg-accent hover:text-white transition-all font-bold text-xs">
                      TWITTER
                   </button>
                   <button className="flex items-center justify-center gap-2 p-3 bg-muted rounded-lg border border-white/5 hover:bg-accent hover:text-white transition-all font-bold text-xs">
                      LINKEDIN
                   </button>
                </div>
                
                <div className="pt-6 space-y-4">
                   <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">About the Author</h4>
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center text-white font-black">S</div>
                      <div>
                         <p className="text-sm font-bold text-white">Sentinel Engine</p>
                         <p className="text-[10px] text-gray-500 uppercase tracking-widest leading-none pt-1">Lead Strategist</p>
                      </div>
                   </div>
                   <p className="text-xs text-gray-400 leading-relaxed font-medium">
                      Reporting on emerging technology vectors and advanced software architectures.
                   </p>
                </div>
             </div>
          </aside>
        </div>
      </div>
    </article>
  );
}
